# Jumpserver 离线录像播放器

[![Build Status](https://travis-ci.com/orangemio/videoplayer-electron.svg?branch=master)](https://travis-ci.com/orangemio/videoplayer-electron)


支持 Jumpserver v1.5.7 以上版本离线下载的录像播放

